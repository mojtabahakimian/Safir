﻿namespace Safir.Shared.Constants
{
    public static class BaseknowClaimTypes
    {
        public const string UUSER = "UUSER";
        public const string IDD = "IDD";
        public const string GRSAL = "GRSAL";
        public const string USER_HES = "HES";
    }
}