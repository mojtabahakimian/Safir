﻿namespace Safir.Shared.Models.Visitory
{
    public class VISITOR_CUSTOMERS
    {
        public string? userid { get; set; }
        public long? VDATE { get; set; }
        public string? hes { get; set; }
        public double? mandahh { get; set; }
        public string? person { get; set; }
        public string? addr { get; set; }
        public int? mandahas { get; set; }
        public long? etebar { get; set; }
        public string? lkharid { get; set; }
        public double? Latitude { get; set; }
        public double? Longitude { get; set; }
        public bool? TOPLACE { get; set; }
        public bool? OKF { get; set; }
    }
}