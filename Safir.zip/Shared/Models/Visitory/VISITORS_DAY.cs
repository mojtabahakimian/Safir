﻿namespace Safir.Shared.Models.Visitory
{
    public class VISITORS_DAY
    {
        public string? HES { get; set; }
        public long? VDATE { get; set; }
        public DateTime? CDATE { get; set; }
        public string? USERNAME { get; set; }
        public bool? OKF { get; set; }
        public DateTime? CRT { get; set; }
        public int? UID { get; set; }
    }
}
