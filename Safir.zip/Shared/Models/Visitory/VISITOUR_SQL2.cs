﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Safir.Shared.Models.Visitory
{
    public class VISITOUR_SQL2
    {
        public string? ROUTE_NAME { get; set; }
        public string? COUST_NO { get; set; }
        public bool? RACTIVE { get; set; }
        public int? IDR { get; set; }
    }

}
